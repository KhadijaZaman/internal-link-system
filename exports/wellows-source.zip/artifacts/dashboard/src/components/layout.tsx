import { Link, useLocation } from "wouter";
import { useLogout } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, Network, TrendingDown, Settings2, LogOut, LineChart, FileText, Ban, PenLine, Link2, Compass, BookOpen, ClipboardList, Bot, Gauge, Table2, ListTodo, Newspaper } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/actions", label: "Action Queue", icon: ListTodo },
  { href: "/digest", label: "Weekly Digest", icon: Newspaper },
  { href: "/submissions", label: "My Submissions", icon: ClipboardList },
  { href: "/link-map", label: "Link Map", icon: Network },
  { href: "/links", label: "Links", icon: Link2 },
  { href: "/authority", label: "Site Authority", icon: Compass },
  { href: "/losers", label: "Query Losers", icon: TrendingDown },
  { href: "/optimize", label: "Optimizer", icon: Settings2 },
  { href: "/knowledge-base", label: "Knowledge Base", icon: BookOpen },
  { href: "/content/writer", label: "Content Writer", icon: PenLine },
  { href: "/gsc/overview", label: "GSC Pro", icon: LineChart },
  { href: "/gsc/ask", label: "Ask AI", icon: Bot },
  { href: "/ga4", label: "GA4 Engagement", icon: Gauge },
  { href: "/report", label: "Page Report", icon: Table2 },
  { href: "/wp/classifications", label: "WP Classifications", icon: FileText },
  { href: "/wp/exclude-list", label: "Exclude List", icon: Ban },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const logout = useLogout();
  const { toast } = useToast();

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        setLocation("/login");
      },
      onError: () => {
        toast({ title: "Failed to logout", variant: "destructive" });
      }
    });
  };

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden">
      {/* Sidebar */}
      <div className="w-64 border-r bg-card flex flex-col">
        <div className="h-16 flex items-center px-6 border-b">
          <h1 className="font-display text-2xl text-primary tracking-wide">WELLOWS</h1>
        </div>
        <div className="flex-1 py-4 flex flex-col gap-1 px-3">
          {navItems.map((item) => {
            const isActive =
              item.href === "/gsc/overview"
                ? location.startsWith("/gsc") && location !== "/gsc/ask"
                : item.href === "/gsc/ask"
                  ? location === "/gsc/ask"
                  : item.href === "/links"
                    ? location.startsWith("/links") ||
                      ["/suggestions", "/semantic-links", "/link-lookups", "/structural"].includes(location)
                    : location === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={isActive ? "secondary" : "ghost"}
                  className="w-full justify-start gap-3 text-sm font-medium"
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Button>
              </Link>
            );
          })}
        </div>
        <div className="p-4 border-t">
          <Button variant="ghost" onClick={handleLogout} className="w-full justify-start gap-3 text-sm font-medium text-muted-foreground">
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <main className="flex-1 overflow-y-auto p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
